class AppRoutes{
  static const homePage = "/";
  static const allTickets = "/all_tickets";
}