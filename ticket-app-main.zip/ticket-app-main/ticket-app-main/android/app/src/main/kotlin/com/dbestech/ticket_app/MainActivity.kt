package com.dbestech.ticket_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
